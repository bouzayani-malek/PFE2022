<template>
<transition
 mode="out-in"
 enter-active-class="animate__animated animate__fadeIn"
>
    <router-view />
    </transition>
</template>

