<template>
  <Menu></Menu>
 <base-layout id="main-content" pageTitle="Profile">
  <ion-card class="rr" >
      <ion-img :src="image"></ion-img>
    <!-- <ion-img :src="image" style="    border-radius: 1000px;
    height: 288px;
    width: 300px;
    
   "
   class="rr"/> -->
    <ion-card-header>
      <ion-card-subtitle>Nom et Prénom :</ion-card-subtitle>
      <ion-card-title>{{nom}} {{prenom}}</ion-card-title>
    </ion-card-header>
    <ion-card-content>
      Email : {{email}} <br>
      Tel : {{tel}} <br>
      Role : {{role}}
    </ion-card-content>
  </ion-card>
  <!-- {{Profil}} -->
  <!-- <br>
  <ion-list>
    <ion-item v-for="d in demandes" :key="d">
      {{d.idDemande}}
    </ion-item>
  </ion-list> -->
 </base-layout>
</template>
<script>
import { IonCard, IonCardContent, IonCardHeader, IonCardSubtitle, IonCardTitle, IonIcon, IonItem, IonLabel } from '@ionic/vue';
import Menu from '../../components/intermediaire/Menu.vue';
// import { mapGetters,  } from 'vuex';
import axios from "axios";
import Url from "../../store/Api";
export default {
  name: 'ClientProfile',
  // computed:{
  //   ...mapGetters(["demandes"])
  // },
   data() {
    return {
      Profil: [],
      role: "",
      nom: "",
      prenom: "",
      email: "",
      password: "",
      cpassword: "",
      user: "",
      class1: "",
      class2: "",
      idUser: "",
      image: "",
      tel: null,
      // success: false,
      // timeout: false,
    };
  },
  async created() {
    await axios
      .get(Url + "intermediaires/" + localStorage.getItem("id"), {
        headers: {
          Authorization: "Bearer " + localStorage.getItem("token"),
        },
      })
      .then((res) => {
        this.Profil = res.data;
        this.image = res.data.imageSrc;
        this.tel = res.data.tel;
        this.user = res.data.idUserNavigation;
        this.role = res.data.idRoleNavigation.role1;
        this.nom = res.data.idUserNavigation.nom;
        this.prenom = res.data.idUserNavigation.prenom;
        this.email = res.data.idUserNavigation.email;
        this.idUser = res.data.idUserNavigation.idUser;
      });
  },
  // mounted(){
  //   this.$store.dispatch('Get_Demandes');
  // },
  components: {
    Menu,
    IonCard,
    IonCardContent,
    IonCardHeader,
    IonCardSubtitle,
    IonCardTitle,
    IonIcon,
    IonItem,
    IonLabel,
    
},
};
</script>
<style>
.rr{
  text-align: center;
}
</style>

