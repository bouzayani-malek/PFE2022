<template>
  <Menu></Menu>
  <base-layout
    id="main-content"
    pageTitle="Les Offres"
    pageDefaultBackLink="/intermediaire/demandes"
  >
    <ion-content :fullscreen="true">
      <ion-progress-bar
        v-if="load"
        type="indeterminate"
      ></ion-progress-bar>
      <ion-card v-if="Offres.length == 0">
        <ion-card-header>
          <ion-card-subtitle></ion-card-subtitle>
          <ion-card-title style="text-align: center"
            >Aucune Offres</ion-card-title
          >
        </ion-card-header>
      </ion-card>
      <ion-card v-for="d in Offres" :key="d">
        <ion-item>
          <ion-icon slot="start" :icon="receiptOutline" ></ion-icon>
          <ion-label>Offre Numéro : {{ d.idOffre }}</ion-label>
        </ion-item>

        <ion-card-content class="rr">
          Transporteur : {{ d.idTransporteurNavigation.idUserNavigation.nom }}
          {{ d.idTransporteurNavigation.idUserNavigation.prenom }}
          <br />
          Prix : {{ d.prix }}
          <br />
          Prix Finale : {{ d.prixFinale }}
          <br />
          <ion-chip>
            <ion-label
              v-if="d.idEtatNavigation.etat == 'Refusé'"
              color="danger"
              >{{ d.idEtatNavigation.etat }}</ion-label
            >
            <ion-label v-else color="primary">{{
              d.idEtatNavigation.etat
            }}</ion-label>
          </ion-chip>
        </ion-card-content>
      </ion-card>
      <br />
      <br />
    </ion-content>
  </base-layout>
</template>
<script>
import {
  IonCard,
  IonCardContent,
  IonCardHeader,
  IonCardSubtitle,
  IonCardTitle,
  IonIcon,
  IonItem,
  IonLabel,
  IonItemSliding,
  IonItemOptions,
  IonItemOption,
} from "@ionic/vue";
import axios from "axios";
import Menu from "../../components/intermediaire/Menu.vue";
// import { mapGetters } from "vuex";
import Url from "../../store/Api";
import {
  cart,
  receiptOutline,
  openOutline,
  documentOutline,
} from "ionicons/icons";
export default {
  name: "ClientDemandes",

  data() {
    return {
      cart,
      openOutline,
      receiptOutline,
      documentOutline,
      Offres: [],
      load:true
    };
  },
  components: {
    Menu,
    IonCard,
    IonCardContent,
    IonCardHeader,
    IonCardSubtitle,
    IonCardTitle,
    IonIcon,
    IonItem,
    IonLabel,
    IonItemSliding,
    IonItemOptions,
    IonItemOption,
  },
  async created() {
    await axios
      .get(Url + "DemandeLivraisons/" + this.$route.params.id, {
        headers: {
          Authorization: "Bearer " + localStorage.getItem("token"),
        },
      })
      .then((res) => {
        console.log(res.data);

        this.Offres = res.data[0].offre;
        this.load=false;
      });
  },
};
</script>
<style>
.rr {
  text-align: center;
}
</style>