<template>
  <Menu></Menu>
  <base-layout id="main-content" pageTitle="Factures Transporteur">
    <ion-toolbar>
      <ion-searchbar
        type="number"
        @ionInput="Shearsh = $event.target.value"
        animated
        autocorrect="on"
      ></ion-searchbar>
      <ion-progress-bar
        v-if="factures.length == 0"
        type="indeterminate"
      ></ion-progress-bar>
    </ion-toolbar>
    <ion-content :fullscreen="true" v-if="demandeSh">
      <ion-card v-for="d in demandeSh" :key="d">
        <ion-item>
          <ion-icon slot="start" :icon="cardOutline" ></ion-icon>
          <ion-label>Numéro facture: {{ d.idFactTransporteur }}</ion-label>
        </ion-item>

        <ion-card-content class="rr">
          <ion-chip>
            <ion-label color="primary" v-if="d.payementFile">Payé</ion-label>
            <ion-label color="danger" v-else> Non Payé</ion-label>
          </ion-chip>
        </ion-card-content>
      </ion-card>
      <br/>
      <br/>
    </ion-content>

    <ion-content :fullscreen="true" v-else>
      <ion-card v-for="d in factures" :key="d">
        <ion-item>
          <ion-icon slot="start" :icon="cardOutline" ></ion-icon>
          <ion-label>Numéro facture: {{ d.idFactTransporteur }}</ion-label>
        </ion-item>

        <ion-card-content class="rr">
          <ion-chip>
            <ion-label color="primary" v-if="d.payementFile">Payé</ion-label>
            <ion-label color="danger" v-else> Non Payé</ion-label>
          </ion-chip>
        </ion-card-content>
      </ion-card>
      <br/>
      <br/>
    </ion-content>
  </base-layout>
</template>
<script>
import {
  IonCard,
  IonCardContent,
  IonCardHeader,
  IonCardSubtitle,
  IonCardTitle,
  IonIcon,
  IonItem,
  IonLabel,
  IonItemSliding,
  IonItemOptions,
  IonItemOption,
} from "@ionic/vue";
import Menu from "../../components/intermediaire/Menu.vue";
import { mapGetters } from "vuex";
import Url from "../../store/Api";
import axios from "axios";
import { cart, trash, openOutline, cardOutline } from "ionicons/icons";
export default {
  name: "ClientDemandes",
  computed: {
    ...mapGetters(["demandes"]),
  },
  mounted() {
    this.$store.dispatch("Get_Demandes");
  },

  async created() {
    await axios
      .get(Url + `facturetransporteurs`, {
        headers: {
          Authorization: "Bearer " + localStorage.getItem("token"),
        },
      })
      .then((res) => {
        this.factures = res.data;
      });
  },
  data() {
    return {
      cart,
      openOutline,
      trash,
      cardOutline,
      Shearsh: "",
      demandeSh: "",
      lien: "/intermediaire/VoirOffre/",
      livrer: "",
      achever: "",
      factures: [],
    };
  },
  components: {
    Menu,
    IonCard,
    IonCardContent,
    IonCardHeader,
    IonCardSubtitle,
    IonCardTitle,
    IonIcon,
    IonItem,
    IonLabel,
    IonItemSliding,
    IonItemOptions,
    IonItemOption,
  },
  methods: {},
  watch: {
    Shearsh() {
      if (this.Shearsh != "") {
        this.demandeSh = this.factures.filter(
          (s) => s.idFactTransporteur == this.Shearsh
        );
      } else {
        this.demandeSh = "";
      }
    },
  },
};
</script>
<style>
.rr {
  text-align: center;
}
</style>