import Url from "../Api.js";
import axios from "axios";
const Token = localStorage.getItem('token');
export default {
  state: {
demandes:[],

  },
  getters: {
    demandes(state){
      return state.demandes;
    }


  },
  mutations: {
    GetDemandes(state,value){
      state.demandes = value;
  }
},
  actions: {

    Get_Demandes({commit}){
      axios.get(Url+'demandelivraisons/client/6')
      .then((resp)=>{
        commit('GetDemandes',resp.data)
      })
    },

  
  },
};
