import validations from './validations.js';

export default {
  validations,
};
