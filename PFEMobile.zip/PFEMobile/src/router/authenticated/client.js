import UserTypes from '../../enums/UserTypes';
//middleware
import log from '../../middleware/log'
import authc from '../../middleware/authc'
export default [
  {
    path: '/client/dashboard',
    name: 'client-dashboard',
    component: () => import('../../pages/client/Dashboard.vue'),
    meta: {
      middleware: [authc, log],
  },
  },
  {
    path: '/client/profile',
    name: 'client-profile',
    component: () => import('../../pages/client/Profile.vue'),
    meta: {
      middleware: [authc, log],
  },
  },
  {
    path: '/client/demandes',
    name: 'client-demandes',
    component: () => import('../../pages/client/demandes.vue'),
    meta: {
      middleware: [authc, log],
  },
  },
  {
    path: '/client/demande',
    name: 'client-demande',
    component: () => import('../../pages/client/demande.vue'),
    meta: {
      middleware: [authc, log],
  },
  },
  {
    path: '/client/offres',
    name: 'client-offres',
    component: () => import('../../pages/client/offres.vue'),
    meta: {
      middleware: [authc, log],
  },
  },
  {
    path: '/client/offre',
    name: 'client-offre',
    component: () => import('../../pages/client/offre.vue'),
    meta: {
      middleware: [authc, log],
  },
  },
  {
    path: '/client/factures',
    name: 'client-factures',
    component: () => import('../../pages/client/factures.vue'),
    meta: {
      middleware: [authc, log],
  },
  },
];
