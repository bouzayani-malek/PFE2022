<template>
<Menu></Menu>
 <base-layout id="main-content" pageTitle="Offres">
  <ion-toolbar>
      <ion-searchbar animated autocorrect="on"></ion-searchbar>
         <ion-progress-bar v-if="offres.length==0" type="indeterminate"></ion-progress-bar>
    </ion-toolbar>
     <ion-content fullscreen>
        <ion-list>
       
          <ion-item v-for="o in offres" :key="o" href="/client/offre">Num : {{o.idOffre}}</ion-item>
        </ion-list>
      </ion-content>
  </base-layout>
</template>
<script>
import { IonCard, IonCardContent, IonCardHeader, IonCardSubtitle, IonCardTitle, IonIcon, IonItem, IonLabel } from '@ionic/vue';
import Menu from '../../components/client/Menu.vue';
import { mapGetters,  } from 'vuex';
export default {
  name: 'ClientOffres',
     computed:{
    ...mapGetters(["offres"])
  },
  mounted(){
    this.$store.dispatch('Get_Offres');
  },
  components: {
    Menu,
    IonCard,
    IonCardContent,
    IonCardHeader,
    IonCardSubtitle,
    IonCardTitle,
    IonIcon,
    IonItem,
    IonLabel,
    
},
};
</script>