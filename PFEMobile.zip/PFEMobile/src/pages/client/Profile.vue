<template>
  <Menu></Menu>
 <base-layout id="main-content" pageTitle="Profile">
  <ion-card>
    <img src="https://2398-20-225-63-138.ngrok.io/File/Image/63483461224024874.jfif" style="    border-radius: 1000px;
    height: 288px;
    width: 300px;"/>
    <ion-card-header>
      <ion-card-subtitle>Client</ion-card-subtitle>
      <ion-card-title>Karim Omrane</ion-card-title>
    </ion-card-header>
    <ion-card-content>
      Email : Karimomrane7@gmail.com <br>
      Tel : 21433145 <br>
      
    </ion-card-content>
  </ion-card>
  <br>
  <ion-list>
    <ion-item v-for="d in demandes" :key="d">
      {{d.idDemande}}
    </ion-item>
  </ion-list>
 </base-layout>
</template>
<script>
import { IonCard, IonCardContent, IonCardHeader, IonCardSubtitle, IonCardTitle, IonIcon, IonItem, IonLabel } from '@ionic/vue';
import Menu from '../../components/client/Menu.vue';
import { mapGetters,  } from 'vuex';
export default {
  name: 'ClientProfile',
  computed:{
    ...mapGetters(["demandes"])
  },
  mounted(){
    this.$store.dispatch('Get_Demandes');
  },
  components: {
    Menu,
    IonCard,
    IonCardContent,
    IonCardHeader,
    IonCardSubtitle,
    IonCardTitle,
    IonIcon,
    IonItem,
    IonLabel,
    
},
};
</script>
