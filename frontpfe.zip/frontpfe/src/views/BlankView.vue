<template>
  <!-- Breadcrumb -->
  <Breadcrumb breadcrumb="Blank" />
</template>

