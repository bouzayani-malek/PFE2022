<template>
<Menu></Menu>
 <base-layout id="main-content" pageTitle="Demandes">
   <ion-toolbar>
      <ion-searchbar animated autocorrect="on"></ion-searchbar>
      <ion-progress-bar v-if="demandesdevis.length==0" type="indeterminate"></ion-progress-bar>
    </ion-toolbar>
     <ion-content fullscreen>
        <ion-list>
          <ion-item v-for="d in demandesdevis" :key="d" href="/transporteur/demande">Num : {{d.idDemandeDevis}}</ion-item>
        </ion-list>
      </ion-content>
  </base-layout>
</template>
<script>

import { IonCard, IonCardContent, IonCardHeader, IonCardSubtitle, IonCardTitle, IonIcon, IonItem, IonLabel } from '@ionic/vue';
import Menu from '../../components/transporteur/Menu.vue';
import { mapGetters,  } from 'vuex';

export default {
  name: 'TransporteurDemandes',
   computed:{
    ...mapGetters(["demandesdevis"])
  },
  mounted(){
    this.$store.dispatch('Get_DemandesDevis');
  },

  components: {
    Menu,
    IonCard,
    IonCardContent,
    IonCardHeader,
    IonCardSubtitle,
    IonCardTitle,
    IonIcon,
    IonItem,
    IonLabel,
    
},
};
</script>