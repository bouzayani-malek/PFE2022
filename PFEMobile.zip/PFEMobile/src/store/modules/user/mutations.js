export default {
  setUserId(state, userId) {
    state.userId = userId;
  },
  setUserType(state, userType) {
    state.userType = userType;
  },
};
