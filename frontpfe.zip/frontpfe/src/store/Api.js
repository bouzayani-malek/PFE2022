//import axios from "axios";

// const url="https://3958-20-225-63-138.ngrok.io/api/";
const url="http://localhost:5000/api/";
export default url;