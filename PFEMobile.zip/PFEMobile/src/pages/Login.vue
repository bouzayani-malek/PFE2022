<template>
  <!-- <base-layout>  -->
   <ion-content class="ion-padding">
     
  
    <ion-row>
      <ion-col size="12">
        <ion-img
          class="mx-auto w-75 mb-4"
          src="assets/icon/easyorder.png"
         style=" width:25%"
        />
        <h2 style="display: flex;
    justify-content: center;">FlexiLogistics</h2>
      </ion-col>
      <ion-col size="12">
        <ion-item class="d-flex align-items-end">
          <ion-icon  slot="start" class="mr-2" :icon="Icon.mail"></ion-icon>
          <ion-label position="floating">Email</ion-label>
          <ion-input
            clear-input
            required
            type="email"
            inputmode="email"
            v-model="email"
            @input="ErrorMessages.email = ''"
          ></ion-input>
        </ion-item>
        <error-message :text="ErrorMessages.email" />
      </ion-col>
      <ion-col size="12">
        <ion-item class="d-flex align-items-end">
          <ion-icon  slot="start" class="mr-2" :icon="Icon.key"></ion-icon>
          <ion-label position="floating">Password</ion-label>
          <ion-input
            required
            name="password"
            clear-input
            v-model="password"
            :type="showPassword ? 'text' : 'password'"
            @input="ErrorMessages.password = ''"
          ></ion-input>
          <ion-icon
             slot="end"
            class="mr-2"
            :icon="showPassword ? Icon.eyeOff : Icon.eye"
            @click="showPassword = !showPassword"
          ></ion-icon>
        </ion-item>
        <error-message :text="ErrorMessages.password" />
      </ion-col>
    </ion-row>
    <ion-row class="mt-3">
      <ion-col size="12">
        <Button
          color="primary"
          text="Login"
          :icon="Icon.enterOutline"
          :isLoading="loading"
          @click="loginUser()"
        />
      </ion-col>
    </ion-row>
    <ion-row class="ion-text-center">
      <!-- <ion-col size="12">
        <ion-text color="tertiary" @click="redirectToRecoveryPassword()">
          Forgot password?
        </ion-text>
      </ion-col> -->
    </ion-row>
      </ion-content>
 <!-- </base-layout>  -->
</template>

<script>
import {
  enterOutline, mail, key, logIn, eye, eyeOff,
} from 'ionicons/icons';

import {
  IonInput,
  IonRow,
  IonCol,
  IonItem,
  IonLabel,
  IonIcon,
  IonText,
} from '@ionic/vue';

//import { mapActions } from 'vuex';

import { useRouter } from 'vue-router';
import { ref } from 'vue';

import Button from '../components/Button.vue';
import useToast from '../composition/useToast';
import login from '../composition/login';
import axios from 'axios';
import url from '../store/Api';
export default {
  name: 'Login',
  components: {
    Button,
    IonInput,
    IonRow,
    IonCol,
    IonItem,
    IonLabel,
    IonIcon,
    IonText,
  },
  setup() {
    const { openToast } = useToast();
    const { userLogin } = login();
    const router = useRouter();

    const showPassword = ref(false);

    const Icon = ref({
      mail,
      key,
      eye,
      eyeOff,
      logIn,
      enterOutline,
    });

    const Fields = ref({
      email: '',
      password: '',
    });

    const ErrorMessages = ref({
      email: '',
      password: '',
    });

    const loading = ref(false);

    return {
      ErrorMessages,
      openToast,
      userLogin,
      loading,
      router,
      Fields,
      Icon,
      showPassword,
      password:'',
      email:''
    };
  },
  methods: {
    //...mapActions('login', ['login']),
    loginUser() {
      // if (!this.validateFields()) {
      //   return;
      // }
          axios
        .post(url+"login", {
          Email: this.email,
          Motdepasse: this.password,
        })
        .then((response) => {
          this.loading = true;
          localStorage.setItem("type", response.data.type);
          if (localStorage.getItem("type") == "intermediaire") {
            localStorage.setItem("token", response.data.type.token);
            localStorage.setItem(
              "id",
              response.data.validUser.intermediaire[0].idIntermediaire
            );
            localStorage.setItem(
              "idRole",
              response.data.validUser.intermediaire[0].idRole
            );
              localStorage.setItem(
              "jwt",
             "foo.bar.baz"
            );
            console.log(localStorage.getItem("jwt"));

            this.router.push({ name: 'intermediaire-dashboard' });
            
// login Transporteur
          } else if (localStorage.getItem("type") == "transporteur") {
            localStorage.setItem("token", response.data.token);
            localStorage.setItem("idtransporteur", response.data.validUser.transporteur[0].idTransporteur);
            localStorage.setItem("iduser", response.data.validUser.idUser);
            localStorage.setItem("name", response.data.validUser.nom);
            localStorage.setItem("prenom", response.data.validUser.prenom);
            localStorage.setItem("email", response.data.validUser.email);
            localStorage.setItem("societe", response.data.validUser.societe);
            localStorage.setItem("image", response.data.validUser.image);
            localStorage.setItem("jwtt", 't');
            this.router.push({ name: 'transporteur-dashboard' });
            
          } else if (localStorage.getItem("type") == "") {
            this.$router.push({ name: "Login" });
          } else {
            localStorage.setItem("token", response.data.token);
            localStorage.setItem("iduser", response.data.validUser.idUser);
            localStorage.setItem("name", response.data.validUser.nom);
            localStorage.setItem("prenom", response.data.validUser.prenom);
            localStorage.setItem("email", response.data.validUser.email);
            localStorage.setItem("societe", response.data.validUser.societe);
            localStorage.setItem("image", response.data.validUser.image);
            localStorage.setItem("clientid", response.data.validUser.client[0].idclient);
            localStorage.setItem("jwtc", 'c');
            this.router.push({ name: 'client-dashboard' });
          }
          
         })
 
      

      // this.userLogin(this.Fields)
      //   .then(() => {
      //     this.emitter.emit('logged');
      //   })
      //   .finally(() => {
      //     this.loading = false;
      //   });
    },
    validateFields() {
      let valid = true;

      if (!this.Fields.email) {
        this.ErrorMessages.email = 'Email invalid';
        valid = false;
      }

      if (!this.Fields.password) {
        this.ErrorMessages.password = 'Password invalid';
        valid = false;
      }

      return valid;
    },
    redirectToRecoveryPassword() {
      this.router.push({ name: 'recovery-password' });
    },
  },
};
</script>

<style scoped>
.facebook-button .button-native {
  --background: var(--facebook-blue);
}
</style>
