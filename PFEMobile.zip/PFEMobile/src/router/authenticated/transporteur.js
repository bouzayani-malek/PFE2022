import UserTypes from '../../enums/UserTypes';
//middleware

import log from '../../middleware/log'
import autht from '../../middleware/autht'

export default [
  {
    path: '/transporteur/dashboard',
    name: 'transporteur-dashboard',
    component: () => import('../../pages/transporteur/Dashboard.vue'),
    meta: {
      middleware: [autht, log],
  },
  },
  {
    path: '/transporteur/profile',
    name: 'transporteur-profile',
    component: () => import('../../pages/transporteur/Profile.vue'),
    meta: {
      middleware: [autht, log],
  },
  },
  {
    path: '/transporteur/demandes',
    name: 'transporteur-demandes',
    component: () => import('../../pages/transporteur/demandes.vue'),
    meta: {
      middleware: [autht, log],
  },
  },
  {
    path: '/transporteur/demande',
    name: 'transporteur-demande',
    component: () => import('../../pages/transporteur/demande.vue'),
    meta: {
      middleware: [autht, log],
  },
  },
  {
    path: '/transporteur/offres',
    name: 'transporteur-offres',
    component: () => import('../../pages/transporteur/offres.vue'),
    meta: {
      middleware: [autht, log],
  },
  },
  {
    path: '/transporteur/offre',
    name: 'transporteur-offre',
    component: () => import('../../pages/transporteur/offre.vue'),
    meta: {
      middleware: [autht, log],
  },
  },
  {
    path: '/transporteur/factures',
    name: 'transporteur-factures',
    component: () => import('../../pages/transporteur/factures.vue'),
    meta: {
      middleware: [autht, log],
  },
  },
];
