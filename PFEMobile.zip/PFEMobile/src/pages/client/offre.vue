<template>
  <Menu></Menu>
  <base-layout id="main-content" pageTitle="Offre">
<ion-card>
   <ion-card-header>
        <ion-card-subtitle> Offre : 24044
          <ion-chip color="warning">
            <ion-label>En cours de traitement</ion-label>
          </ion-chip>
        </ion-card-subtitle>
        <ion-card-title>Desciption :Meuble</ion-card-title>
      </ion-card-header>
       <ion-card-content>
        Prix : 35 DT <br>
        Date : 2022-05-15 <br>
        Transporteur : 
        <ion-thumbnail style="display: flex;
    align-items: center;
    flex-direction: row;
    width: 95px;">
    <img src="http://2398-20-225-63-138.ngrok.io/File/Image/277165858_220118748.jpg">
  Feriel Beltaief
  </ion-thumbnail>
      </ion-card-content>
</ion-card>

    <ion-card>
      <ion-slides pager="true">
        <ion-slide>
          <img src="https://toucali.com/wp-content/uploads/2021/08/17708-meuble-tv-d-angle-blanc-darina.jpg" />
        </ion-slide>
        <ion-slide>
          <img
            src="https://cdn.laredoute.com/products/7/2/c/72c24e0e357a51a3671154a9c691a7a8.jpg?imgopt=twic&twic=v1/resize=640" />
        </ion-slide>
      </ion-slides>

      <ion-card-header>
        <ion-card-subtitle> Demande : 7021
          <ion-chip color="danger">
            <ion-label>Non tarité</ion-label>
          </ion-chip>
        </ion-card-subtitle>
        <ion-card-title>Desciption : Livraison de meuble</ion-card-title>
      </ion-card-header>
      <ion-card-content>
        Poid : 100 Kg <br>
        Hauteur : 800 Cm <br>
        Largeur : 1500 Cm <br>
        Destination : Tunis => Djerba <br>
        Date : 2022-05-15
      </ion-card-content>
    </ion-card>
  </base-layout>
</template>
<script>
import { IonCard, IonCardContent, IonSlides, IonCardHeader, IonCardSubtitle, IonCardTitle, IonIcon, IonItem, IonLabel } from '@ionic/vue';
import Menu from '../../components/client/Menu.vue';
import { mapGetters, } from 'vuex';
export default {
  name: 'ClientDemande',
  components: {
    Menu,
    IonCard,
    IonCardContent,
    IonCardHeader,
    IonCardSubtitle,
    IonCardTitle,
    IonIcon,
    IonItem,
    IonLabel,
    IonSlides
  },
};
</script>