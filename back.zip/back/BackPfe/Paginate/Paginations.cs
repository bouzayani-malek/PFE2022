﻿namespace BackPfe.Paginate
{
    public class Paginations
    {

        public int Page { get; set; } = 1;
        public int QuantityPage { get; set; } = 1000;

    }
}