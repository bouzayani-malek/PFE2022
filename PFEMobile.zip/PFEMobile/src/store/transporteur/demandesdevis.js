import Url from "../Api.js";
import axios from "axios";
const Token = localStorage.getItem('token');
export default {
  state: {
demandesdevis :[],

  },
  getters: {
    demandesdevis(state){
      return state.demandesdevis;
    }


  },
  mutations: {
    GetDemandesDevis(state,value){
      state.demandesdevis = value;
  }
},
  actions: {

    Get_DemandesDevis({commit}){
      axios.get(Url+'DemandeDevis/3/traite?etat=Accepte')
      .then((resp)=>{
        commit('GetDemandesDevis',resp.data)
      })
    },

  
  },
};
