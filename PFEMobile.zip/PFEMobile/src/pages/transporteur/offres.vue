<template>
<Menu></Menu>
 <base-layout id="main-content" pageTitle="Offres">
  <ion-toolbar>
      <ion-searchbar animated autocorrect="on"></ion-searchbar>
         <ion-progress-bar v-if="offrestransporteur.length==0" type="indeterminate"></ion-progress-bar>
    </ion-toolbar>
     <ion-content fullscreen>
        <ion-list>
       
          <ion-item v-for="o in offrestransporteur" :key="o" href="/transporteur/offre">Num : {{o.idOffre}}</ion-item>
        </ion-list>
  
      </ion-content>
  </base-layout>
</template>
<script>
import { IonCard, IonCardContent, IonCardHeader, IonCardSubtitle, IonCardTitle, IonIcon, IonItem, IonLabel } from '@ionic/vue';
import Menu from '../../components/transporteur/Menu.vue';
import { mapGetters,  } from 'vuex';
export default {
  name: 'TransporteurOffres',
     computed:{
    ...mapGetters(["offrestransporteur"])
  },
  mounted(){
    this.$store.dispatch('Get_Offres_Transporteur');
  },
  components: {
    Menu,
    IonCard,
    IonCardContent,
    IonCardHeader,
    IonCardSubtitle,
    IonCardTitle,
    IonIcon,
    IonItem,
    IonLabel,
    
},
};
</script>