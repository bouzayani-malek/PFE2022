<template>
  <Menu></Menu>
  <base-layout id="main-content" pageTitle="Factures">
    <ion-toolbar>
      <ion-searchbar></ion-searchbar>
    </ion-toolbar>
  </base-layout>
</template>
<script>
import { IonCard, IonCardContent, IonSearchbar, IonCardHeader, IonCardSubtitle, IonCardTitle, IonIcon, IonItem, IonLabel } from '@ionic/vue';
import Menu from '../../components/client/Menu.vue';
import { mapGetters, } from 'vuex';
export default {
  name: 'ClientFactures',
  components: {
    Menu,
    IonCard,
    IonCardContent,
    IonCardHeader,
    IonCardSubtitle,
    IonCardTitle,
    IonIcon,
    IonItem,
    IonLabel,
    IonSearchbar
  },
};
</script>