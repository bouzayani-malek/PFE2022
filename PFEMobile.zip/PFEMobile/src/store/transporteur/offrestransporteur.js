import Url from "../Api.js";
import axios from "axios";
const Token = localStorage.getItem('token');
export default {
  state: {
    offrestransporteur:[],

  },
  getters: {
    offrestransporteur(state){
      return state.offrestransporteur;
    }


  },
  mutations: {
    GetOffresTransporteur(state,value){
      state.offrestransporteur = value;
  }
},
  actions: {
    Get_Offres_Transporteur({commit}){
      axios.get(Url+'offres/3/offrestransporteur')
      .then((resp)=>{
        commit('GetOffresTransporteur',resp.data)
      })
    },

  
  },
};
