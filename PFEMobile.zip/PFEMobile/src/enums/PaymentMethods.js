export default {
  INCASH: 1,
  BILLET: 2,
};
