<template>
  <Menu></Menu>
  <base-layout id="main-content" pageTitle="Demande de livraison">
    <ion-toolbar>
      <ion-searchbar type="number"  @ionInput="Shearsh = $event.target.value" animated autocorrect="on"></ion-searchbar>
      <ion-progress-bar
        v-if="demandes.length == 0"
        type="indeterminate"
      ></ion-progress-bar>
    </ion-toolbar>
    <ion-content :fullscreen="true" v-if="demandeSh" >
      <ion-card  v-for="d in demandeSh" :key="d">
        <ion-item >
          <ion-icon slot="start"  :icon="documentOutline" ></ion-icon>
          <ion-label>Numéro : {{ d.idDemande }}</ion-label>
          <ion-button  :href="lien+d.idDemande" >offre</ion-button>
        </ion-item>

        <ion-card-content class="rr">
          Adress Départ : {{ d.adressdepart }}
          <br />
          Adress Arrive : {{ d.adressarrive }}
          <br />
          <ion-chip>
            <ion-label color="primary">{{
              d.idEtatdemandeNavigation.etatDemande
            }}</ion-label>
          </ion-chip>
        </ion-card-content>
      </ion-card>
    </ion-content>

     <ion-content :fullscreen="true" v-else >
      <ion-card  v-for="d in demandes" :key="d">
        <ion-item >
          <ion-icon slot="start"  :icon="documentOutline" ></ion-icon>
          <ion-label>Numéro : {{ d.idDemande }}</ion-label>
          <ion-button :href="lien+d.idDemande" >offre</ion-button>
        </ion-item>

        <ion-card-content class="rr">
          Adress Départ : {{ d.adressdepart }}
          <br />
          Adress Arrive : {{ d.adressarrive }}
          <br />
          <ion-chip>
            <ion-label color="primary">{{
              d.idEtatdemandeNavigation.etatDemande
            }} </ion-label>
          </ion-chip>
        </ion-card-content>
      </ion-card>
      <br/>
      <br/>
    </ion-content>
  </base-layout>
</template>
<script>
import {
  IonCard,
  IonCardContent,
  IonCardHeader,
  IonCardSubtitle,
  IonCardTitle,
  IonIcon,
  IonItem,
  IonLabel,
  IonItemSliding,
  IonItemOptions,
  IonItemOption,
  
} from "@ionic/vue";
import Menu from "../../components/intermediaire/Menu.vue";
import { mapGetters } from "vuex";
import { cart, trash, openOutline, documentOutline } from "ionicons/icons";
export default {
  name: "ClientDemandes",
  computed: {
    ...mapGetters(["demandes"]),
  },
  mounted() {
    this.$store.dispatch("Get_Demandes");
  },
  data() {
    return {
      cart,
      openOutline,
      trash,
      documentOutline,
      Shearsh:"",
      demandeSh: "",
      lien:"/intermediaire/VoirOffre/"
    };
  },
  components: {
    Menu,
    IonCard,
    IonCardContent,
    IonCardHeader,
    IonCardSubtitle,
    IonCardTitle,
    IonIcon,
    IonItem,
    IonLabel,
    IonItemSliding,
    IonItemOptions,
    IonItemOption,
  },
  methods:{
    VoirOffre(id){
       this.$router.push({ name: "Voir-offre", params: { id: id } });
    }
  },
  watch:{
       Shearsh() {
      if (this.Shearsh != "") {
      this.demandeSh = this.demandes.filter((s) =>
          s.idDemande==this.Shearsh
        );
      } else {
        this.demandeSh = "";
      }
    }, 
  }
};
</script>
<style>
.rr{
  text-align: center;
}

</style>