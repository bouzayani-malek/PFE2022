import { createStore } from 'vuex';
//client
import demandes from './client/demandes';
import demandesdevis from './transporteur/demandesdevis';
import offres from './client/offres';
import offrestransporteur from './transporteur/offrestransporteur';
import general from './modules/general/index';
import login from './modules/login/index';
import files from './modules/files/index';
import user from './modules/user/index';
import menu from './modules/menu/index';

const store = createStore({
  modules: {
    demandesdevis,
    offrestransporteur,
    demandes,
    general,
    login,
    files,
    user,
    menu,
    offres
  },
});

export default store;
