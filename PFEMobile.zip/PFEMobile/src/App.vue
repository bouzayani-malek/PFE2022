<template>
  <IonApp>
    <ion-router-outlet></ion-router-outlet>
  </IonApp>
</template>

<script>
import { IonApp, IonRouterOutlet } from "@ionic/vue";

import { defineComponent } from "vue";
//  import { FCM } from "@capacitor-community/fcm";
//  import { Plugins } from '@capacitor/core';

export default defineComponent({
  name: "App",
  components: {
    IonApp,
    IonRouterOutlet,
    // IonSplitPane,
  },
  // data() {
  //   return {
  //      fcm: new FCM(),
  //   };
  // },
});
</script>
