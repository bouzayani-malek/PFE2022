// import UserTypes from '../../enums/UserTypes';
//middleware
import auth from '../../middleware/auth'
import log from '../../middleware/log'

export default [
  {
    path: '/intermediaire/dashboard',
    name: 'intermediaire-dashboard',
    component: () => import('../../pages/intermediaire/Dashboard.vue'),
    meta: {
      middleware: [auth, log],
  },
  },
  {
    path: '/intermediaire/profile',
    name: 'intermediaire-profile',
    component: () => import('../../pages/intermediaire/Profile.vue'),
    meta: {
      middleware: [auth, log],
  },
  },
  {
    path: '/intermediaire/demandes',
    name: 'intermediaire-demandes',
    component: () => import('../../pages/intermediaire/demandes.vue'),
    meta: {
      middleware: [auth, log],
  },
  },
  {
    path: '/intermediaire/VoirOffre/:id',
    name: 'Voir-offre',
    component: () => import('../../pages/intermediaire/Offre.vue'),
    meta: {
      middleware: [auth, log],
  },
  },
  {
    path: '/intermediaire/factureClient',
    name: 'intermediaire-factureClient',
    component: () => import('../../pages/intermediaire/FacturesClient.vue'),
    meta: {
      middleware: [auth, log],
  },
  },
  {
    path: '/intermediaire/factureTransporteur',
    name: 'intermediaire-factureTransporteur',
    component: () => import('../../pages/intermediaire/FactureTransporteur.vue'),
    meta: {
      middleware: [auth, log],
  },
  },
  // {
  //   path: '/client/offre',
  //   name: 'client-offre',
  //   component: () => import('../../pages/client/offre.vue'),
  //   meta: {
  //     middleware: [auth, log],
  // },
  // },
  // {
  //   path: '/client/factures',
  //   name: 'client-factures',
  //   component: () => import('../../pages/client/factures.vue'),
  //   meta: {
  //     middleware: [auth, log],
  // },
  // },
];
