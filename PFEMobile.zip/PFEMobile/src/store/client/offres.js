import Url from "../Api.js";
import axios from "axios";
const Token = localStorage.getItem('token');
export default {
  state: {
offres:[],

  },
  getters: {
    offres(state){
      return state.offres;
    }


  },
  mutations: {
    GetOffres(state,value){
      state.offres = value;
  }
},
  actions: {
    Get_Offres({commit}){
      axios.get(Url+'offres/client/6')
      .then((resp)=>{
        commit('GetOffres',resp.data)
      })
    },

  
  },
};
