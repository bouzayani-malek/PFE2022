<template>
  <Menu></Menu>
 <base-layout id="main-content" pageTitle="Profile">
  <ion-card>
    <img src="http://2398-20-225-63-138.ngrok.io/File/Image/277165858_220118748.jpg" style="    border-radius: 1000px;
    height: 288px;
    width: 300px;"/>
    <ion-card-header>
      <ion-card-subtitle>Transporteur</ion-card-subtitle>
      <ion-card-title>Feriel Beltaief</ion-card-title>
    </ion-card-header>
    <ion-card-content>
      Email : feriel@gmail.com <br>
      Tel : 96692466 <br>
      
    </ion-card-content>
  </ion-card>

 </base-layout>
</template>
<script>
import { IonCard, IonCardContent, IonCardHeader, IonCardSubtitle, IonCardTitle, IonIcon, IonItem, IonLabel } from '@ionic/vue';
import Menu from '../../components/transporteur/Menu.vue';
import { mapGetters,  } from 'vuex';
export default {
  name: 'TransporteurProfile',
  computed:{
    ...mapGetters(["demandes"])
  },
  mounted(){
    this.$store.dispatch('Get_Demandes');
  },
  components: {
    Menu,
    IonCard,
    IonCardContent,
    IonCardHeader,
    IonCardSubtitle,
    IonCardTitle,
    IonIcon,
    IonItem,
    IonLabel,
    
},
};
</script>
