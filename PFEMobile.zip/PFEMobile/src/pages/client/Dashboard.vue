<template>
  <Menu></Menu>
  <!-- <ion-page >
    <ion-header>
      <ion-toolbar>
      </ion-toolbar>
    </ion-header>
  </ion-page>
  <ion-content class="ion-padding" id="main-content">
    Home client
  </ion-content> -->
  <base-layout id="main-content" pageTitle="Dashboard">
      <ion-slides pager="true">
      <ion-slide>
        <!-- <div class="slide"> -->
        <!-- card -->
        <ion-card>
          <ion-card-header>
            <ion-card-subtitle style="text-align: center"
              >Personnel</ion-card-subtitle>
            <ion-card-title style="text-align: center">2</ion-card-title>
          </ion-card-header>
        </ion-card>
      
      </ion-slide>

      <ion-slide>
       
        <ion-card>
          <ion-card-header>
            <ion-card-subtitle style="text-align: center"
              >Demandes</ion-card-subtitle
            >
            <ion-card-title style="text-align: center">6</ion-card-title>
          </ion-card-header>
        </ion-card>
        <!-- fin card -->
      </ion-slide>

      <ion-slide>
       
        <ion-card>
          <ion-card-header>
            <ion-card-subtitle style="text-align: center"
              >Offres</ion-card-subtitle
            >
            <ion-card-title style="text-align: center">3</ion-card-title>
          </ion-card-header>
        </ion-card>
        <!-- fin card -->
      </ion-slide>
    </ion-slides>
    <ion-content>

<VCalendar :demandes = "demandes"></VCalendar>
        
    </ion-content>
  </base-layout>

</template>

<script>
import Menu from '../../components/client/Menu.vue';
import {
  person,
  people,
  settings,
  list
} from "ionicons/icons";
import {
  IonContent,
  IonIcon,
  IonGrid,
  IonRow,
  IonCol,
  IonCard,

} from "@ionic/vue";
import VCalendar from './components/v-calendar.vue';
import axios from 'axios';
import { mapGetters,  } from 'vuex';
export default {
  name: 'ClientHome',
  data() {
    return {
      person,
      people,
      settings,
      list,
    };
  },
  computed:{
    ...mapGetters(["demandes"])
  },
  mounted(){
    this.$store.dispatch('Get_Demandes');
  },

  created(){
  // axios
  //     .get(
  //       "http://localhost:5000/api/demandelivraisons/client/" +
  //       localStorage.getItem("iduser")
  //     )
  //     .then((resp) => {
  //       this.demandes = resp.data;
  //     });
  },
  components: {
    Menu,
    IonContent,
    IonIcon,
    IonGrid,
    IonRow,
    IonCol,
    IonCard,
    VCalendar
},
};
</script>
<style>
.icon {
  font-size: 50px;
}
.swiper-slide {
  display: block;
}
</style>