<template>
<Menu></Menu>
 <base-layout id="main-content" pageTitle="Demandes">
   <ion-toolbar>
      <ion-searchbar animated autocorrect="on"></ion-searchbar>
      <ion-progress-bar v-if="demandes.length==0" type="indeterminate"></ion-progress-bar>
    </ion-toolbar>
     <ion-content fullscreen>
        <ion-list>
          <ion-item v-for="d in demandes" :key="d" href="/client/demande">Num : {{d.idDemande}}</ion-item>
        </ion-list>
      </ion-content>
  </base-layout>
</template>
<script>

import { IonCard, IonCardContent, IonCardHeader, IonCardSubtitle, IonCardTitle, IonIcon, IonItem, IonLabel } from '@ionic/vue';
import Menu from '../../components/client/Menu.vue';
import { mapGetters,  } from 'vuex';

export default {
  name: 'ClientDemandes',
   computed:{
    ...mapGetters(["demandes"])
  },
  mounted(){
    this.$store.dispatch('Get_Demandes');
  },

  components: {
    Menu,
    IonCard,
    IonCardContent,
    IonCardHeader,
    IonCardSubtitle,
    IonCardTitle,
    IonIcon,
    IonItem,
    IonLabel,
    
},
};
</script>