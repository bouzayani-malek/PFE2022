<template>
  <Menu></Menu>
  <base-layout id="main-content" pageTitle="Dashboard">
    <ion-slides>
      <ion-slide>
        <!-- <div class="slide"> -->
        <!-- card -->
        <ion-card>
          <ion-card-header>
            <ion-card-subtitle style="text-align: center"
              >Personnel</ion-card-subtitle
            >
            <ion-card-title style="text-align: center">2</ion-card-title>
          </ion-card-header>
        </ion-card>
      
      </ion-slide>

      <ion-slide>
       
        <ion-card>
          <ion-card-header>
            <ion-card-subtitle style="text-align: center"
              >Transporteur</ion-card-subtitle
            >
            <ion-card-title style="text-align: center">6</ion-card-title>
          </ion-card-header>
        </ion-card>
        <!-- fin card -->
      </ion-slide>

      <ion-slide>
       
        <ion-card>
          <ion-card-header>
            <ion-card-subtitle style="text-align: center"
              >client</ion-card-subtitle
            >
            <ion-card-title style="text-align: center">3</ion-card-title>
          </ion-card-header>
        </ion-card>
        <!-- fin card -->
      </ion-slide>
    </ion-slides>

   
    <VCalendar :demandes = "demandes"></VCalendar>
  </base-layout>
</template>

<script>
import { mapGetters,  } from 'vuex';
import VCalendar from './components/v-calendar.vue';
import Menu from "../../components/intermediaire/Menu.vue";
import BaseLayout from "../../components/base/BaseLayout.vue";
export default {
  name: "IntermediaireHome",
  components: {
    Menu,
    BaseLayout,
    VCalendar
  },
  computed:{
    ...mapGetters(["demandes"])
  },
  mounted(){
    this.$store.dispatch('Get_Demandes');
  },
};
</script>
<style>
.swiper-slide {
  display: block;
}
</style>
