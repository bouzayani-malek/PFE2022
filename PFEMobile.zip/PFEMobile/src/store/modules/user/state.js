export default {
  userId: 0,
  userType: 0,
};
