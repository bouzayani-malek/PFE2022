<template>
  <ion-page >
    <ion-header>
      <ion-toolbar>
        <ion-buttons >
           <div v-if="pageDefaultBackLink">
            <ion-back-button
              text="Back"
              v-if="!ignoreHistory"
              :default-href="pageDefaultBackLink"
            ></ion-back-button>
            <ion-back-button
              v-else
              text="Back"
              @click.prevent="back()"
              :href="pageDefaultBackLink"
              default-href=""
            ></ion-back-button>
          </div> 
           <ion-menu-button
           v-else
            color="primary"
            v-show="showMenuButton"
          ></ion-menu-button>
      
        <ion-text v-if="!pageDefaultBackLink" class="ml-4 font-weight-bold">{{pageTitle}}</ion-text>
        </ion-buttons>
        
        <ion-buttons class="ml-auto"  slot="end"  v-show="showMenuButton" >
            <router-link to="/logout" >
         <ion-icon :icon="power" ></ion-icon>
         </router-link>
         <!-- <slot name="actions-end"></slot> -->
        </ion-buttons>
      </ion-toolbar>
    </ion-header>
    <ion-content  >
      <slot/>
      
    </ion-content>
   <ion-footer class="ion-no-border">
    <ion-toolbar>
      <ion-title>PFE - MALEK - FERIEL - KARIM </ion-title>
    </ion-toolbar>
  </ion-footer>
  </ion-page>
</template>

<script>
import {
  
  power,
  
} from "ionicons/icons";
import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonContent,
  IonBackButton,
  IonButtons,
  IonMenuButton,
  IonFooter
} from '@ionic/vue';
import { useRouter } from 'vue-router';

export default {
  name: 'BaseLayout',
  props: {
    pageTitle: {
      type: String,
      required: false,
    },
    pageDefaultBackLink: {
      type: String,
      required: false,
    },
    showMenuButton: {
      type: Boolean,
      default: true,
    },
    ignoreHistory: {
      type: Boolean,
      default: false,
    },
    className: {
      type: String,
      required: false,
    },
  },
  components: {
    IonPage,
    IonHeader,
    IonToolbar,
    IonContent,
    IonBackButton,
    IonButtons,
    IonMenuButton,
    IonFooter
  },
  setup() {
    const router = useRouter();

    return {
      router,
    };
  },
  data(){
    return{
      power
    }
  },
  methods: {
    back() {
      this.router.push(this.pageDefaultBackLink);
    },
  },
};
/*    <ion-menu-button
            color="primary"
            v-show="showMenuButton"
          ></ion-menu-button>*/
</script>
