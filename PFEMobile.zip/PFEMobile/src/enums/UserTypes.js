export default {
  CLIENT: 1,
  ADMINISTRATOR: 2,
};
